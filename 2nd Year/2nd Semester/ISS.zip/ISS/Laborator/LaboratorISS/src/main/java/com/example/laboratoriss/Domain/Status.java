package com.example.laboratoriss.Domain;

public enum Status {
    ONORATA, IN_ASTEPTARE, REFUZATA
}
