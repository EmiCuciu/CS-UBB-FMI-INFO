package com.example.laboratoriss.Utils.Observer;

public enum ChangeEventType {
    ADD, UPDATE, DELETE
}
