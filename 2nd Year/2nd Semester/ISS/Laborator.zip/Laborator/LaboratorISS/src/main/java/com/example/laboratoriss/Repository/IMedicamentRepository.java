package com.example.laboratoriss.Repository;

import com.example.laboratoriss.Domain.Medicament;

public interface IMedicamentRepository extends IRepository<Integer, Medicament> {

}
