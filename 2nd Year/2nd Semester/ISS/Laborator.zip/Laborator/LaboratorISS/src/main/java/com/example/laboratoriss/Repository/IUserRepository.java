package com.example.laboratoriss.Repository;

import com.example.laboratoriss.Domain.User;

public interface IUserRepository extends IRepository<Integer, User> {
    /**
     * some methods for user
     */
}
