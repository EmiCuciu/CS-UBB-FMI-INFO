package com.example.laboratoriss.Domain;

public enum UserType {
    FARMACIST, PERSONAL_SECTIE;
}
